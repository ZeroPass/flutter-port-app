import 'package:port_mobile_app/utils/storage.dart';
/*
StorageNode _$StorageNodeFromJson(Map<String, dynamic> json) {
  return StorageNode(
    name: json['name'] as String,
    host: json['host'] as String,
    isEncryptedEndpoint: json['isEncryptedEndpoint'] as bool,
    port: json['port'] as int,
    networkType: json['networkType'] as bula,
    chainID: json['chainID'] as String,
    //dateOfBirth: DateTime.parse(json['dateOfBirth'] as String),
  );
}

Map<String, dynamic> _$StorageNodeToJson(StorageNode instance) => <String, dynamic>{
  'name': instance.name,
  'host': instance.host,
  'isEncryptedEndpoint': instance.isEncryptedEndpoint,
  'port': instance.port,
  'networkType': instance.networkType,
  'chainID': instance.chainID,
  //'dateOfBirth': instance.dateOfBirth.toIso8601String(),
};*/