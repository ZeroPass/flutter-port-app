import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:card_settings/card_settings.dart';


//not in use anymore
/*
Widget CustomCardSettingsSection({
        required List<CardSettingsWidget> children,
        String? header,
        Divider? divider
})
{
    if (divider == null)
      divider = Divider(indent: 30, endIndent: 30,);

    return CardSettingsSection(
          divider: divider,
          children: children,
          header: header != null ? CardSettingsHeader(label: header) : null
    );

  }
*/